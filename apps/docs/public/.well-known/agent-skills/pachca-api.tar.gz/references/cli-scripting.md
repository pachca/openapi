# CLI in scripts, CI and agents

Sources of truth: <https://dev.pachca.com/guides/cli/authentication.md>, <https://dev.pachca.com/guides/cli/scripting.md>, <https://dev.pachca.com/guides/cli/output.md>, <https://dev.pachca.com/guides/cli/api-requests.md>. Every command has `--help`; this file is about using them safely in automation.

## Where the token comes from

Priority, highest first:

1. `--token <value>`: one call, nothing saved.
2. `--profile <name>`: a profile named on the command line wins over `PACHCA_TOKEN`.
3. `PACHCA_TOKEN`: the headless path for CI and agents.
4. `PACHCA_PROFILE`.
5. The active profile, set with `pachca auth switch`.

Choose by situation:

- **Employee at a terminal**: `pachca auth login` once (browser, one-hour token refreshed by itself). `--no-browser` prints the address and code on a machine without a display. Parallel CLI processes share one refresh.
- **CI, scripts, bots**: a ready token (personal from **Интеграции > API**, or a bot token from the bot card). Put it in the CI secret store and pass it as `PACHCA_TOKEN`. Never commit it.
- **Saving a ready token on a workstation**: pipe it so it stays out of shell history and the process list: `pbpaste | pachca auth login --token -` (or from a secret manager to stdin). Passing the value as an argument leaves a trace in both. A new bot token goes straight from the API into a profile, never shown: `pachca bots create-token <id> --name "CLI" --scopes '["profile:read",…]' -o csv -c token --no-header | pachca auth login --profile <name> --token -` (without `--scopes` the token has no scopes; `profile:read` lets the CLI show the bot's name).
- **Personal and bot side by side**: separate profiles, for example `--profile bot-notify`; each profile has its own login.

Storage: the token goes to the OS key store. Where there is none (headless machine, container), the CLI writes it in plain text to the config file and says so at login; `PACHCA_SECRET_STORE=file` or `--insecure-storage` forces that. Anyone with access to that account then has API access. For CI prefer `PACHCA_TOKEN` over a saved profile. `PACHCA_HOME` isolates the config directory (CI, tests, agents).

A token kept in the OS key store is tied to that machine: copying the profile elsewhere does not carry the secret.

Ending access:

- `pachca auth logout` after a browser login removes the profile and closes the login on the server: if the saved one-hour token has run out or is about to, it refreshes it first and revokes the fresh one. In JSON, `token_revoked: true` means the login is closed on the server, also when it had been closed earlier (for example in the **Токены CLI** list). `token_revoked: false` means the CLI could not confirm it (offline, a server error): the profile is gone, but the login may still be valid and stays in that list. Then tell the user to revoke it with **Отозвать** in the **Токены CLI** list on **Интеграции > API**.
- `pachca auth login` again into a profile that had a browser login closes the previous login on the server. In JSON, `previous_token_revoked: false` means it could not be closed: tell the user to revoke it in the **Токены CLI** list.
- A ready token keeps working after logout: it never expires. Delete it in Pachca when it is no longer needed.

## Diagnosing auth

- `pachca auth status`: whose token the commands use, picked in the order above, and its scopes. For a token from `PACHCA_TOKEN` or `--token` it asks the server: `-o json` gives `source`, `user`, `user_id` and `scopes`, and `unused_profile` names a saved profile the variable hides. Without `profile:read` the CLI cannot read the owner's name or tell a bot from an employee: `user` is `User #<user_id>`, `email` and `type` are `null`. `expires_in` is set for a one-hour token, which the CLI does not renew. For a saved profile it shows the login method, time left and the scopes saved at login. Before CLI 2026.11.1 it read only a saved profile: it answered `No active profile` to a lone `PACHCA_TOKEN` and, next to a saved profile, showed that profile instead of the variable's token (its `-o json` has no `source`). Then update the CLI, or run `pachca oauth token-info -o json`, which returns the token's scopes and owner (`user_id`) and needs no scope itself. Start here on `PACHCA_SCOPE_ERROR` or `PACHCA_AUTH_ERROR`. A `403` typed `PACHCA_API_ERROR` is about access to the object (closed chat, chat rule, role), not the token. The exception is `validation_code` `access_denied`: the token's owner is an employee whose access is suspended or deleted, and no token or login fixes that.
- `pachca auth status --remote`: asks the server and updates the saved profile's scope list, which does not refresh by itself.
- A scope the token lacks comes back as `403` with type `PACHCA_SCOPE_ERROR`, the missing scope in field `scope` and hint `pachca auth status` (with `--remote` for a saved profile, and with the command's `--token <token>` or `--profile <name>`). After a browser login, log in again only if the role allows that scope now or the scope appeared after the login: a browser login gets only what the role allowed when it was approved, so otherwise a new login lacks the scope too and only an admin changing the role helps. With a ready token, issue one with that scope. A scope the token has but the role does not allow comes back as type `PACHCA_AUTH_ERROR` with `message` `role_forbidden` and no scope named: a new login or token does not help, only someone with that role or an admin can. Only in an interactive terminal (no `-o json`, no pipe) does the CLI also explain both refusals in words; JSON output is unchanged.
- `pachca doctor`: environment diagnostics (Node.js, network, config file, profile, token, CLI version). It checks the token the other commands would use, picked in the order above. With a token from `PACHCA_TOKEN` or `--token` the profile check is `skipped`, and so is the config check when there is no config file, so it passes in CI with `PACHCA_TOKEN` alone. A check with `status` `error` makes it exit with `1`, with `-o json` too.

## Non-interactive mode

It turns on when stdin or stdout is not a TTY, when `PACHCA_PROMPT_DISABLED` or `CI` is set, or with `--no-input`: no prompts, and a missing required flag is an error. `pachca auth login` without `--token` fails here. The progress spinner follows the same conditions except `--no-input`: in a terminal it still shows with `--no-input`, unless `--quiet` or `--dry-run` is passed.

```bash
PACHCA_TOKEN="$PACHCA_SECRET" pachca messages create --entity-id 123 --content "Deploy finished" --no-input
```

## Output

- Default: a table when stdout is a terminal, JSON when it is not (pipes, CI runners). `defaults.output` in the CLI config replaces this default, so scripts that parse output always pass `-o json` (or `--json`). Other formats: `-o yaml|csv|table`.
- `--columns id,email`, `--no-header`, `--no-truncate` for tables. `--plain`: TSV, no header, `id` first, no colour, for `cut` and `awk`.
- Data goes to stdout; errors, warnings and progress to stderr.
- `--all` loads every page and prints one array, and stops at a page cap: see [pagination.md](pagination.md). Without `--all` a typed list command prints one page of `data` and no `meta`, so it never shows the next cursor. To page by hand, use `pachca api GET <path> --query limit=50 --query cursor=<next_page>`, whose output keeps `meta.paginate`.
- Text can come from stdin: `echo "Done" | pachca messages create --entity-id 123`.

## Flags

- Flags are kebab-case (`--entity-id`, `--parent-message-id`); the CLI converts them to the API's snake_case. Check the body with `--dry-run`, which shows the request without sending it.
- Booleans: `--flag` sets `true`, `--no-flag` sets `false`.
- `null`: in a field that accepts `null`, the literal `null` goes out as JSON null. `pachca bots update <id> --kind null` deletes the bot's incoming webhook, `pachca drafts update <id> --parent-message-id null` takes the reply off a draft.
- Typed commands that send `DELETE` (`delete`, `remove`, `unpin`, `leave`, `delete-token` and the like) ask for confirmation in a terminal. In non-interactive mode they refuse without `--force` (`PACHCA_DESTRUCTIVE_OP_ERROR`, exit code `2`). Add `--force` only for a deletion the user asked for, never just to get past that error.
- Also useful: `--verbose` (show HTTP), `--timeout` (seconds, default 30), `--no-retry`, `-q` (exit code and errors only).

## Exit codes and error JSON

| Code | Meaning                                                                                                                                               |
| ---- | ----------------------------------------------------------------------------------------------------------------------------------------------------- |
| `0`  | Success                                                                                                                                               |
| `1`  | API or runtime error, including `400`, `429`, `5xx` and a `403` with an `errors` array: access to the object, or `access_denied` (`PACHCA_API_ERROR`) |
| `2`  | Bad flags or arguments, a `422` from the API (`PACHCA_VALIDATION_ERROR`), a delete without `--force` in non-interactive mode                          |
| `3`  | Authentication: no token, `401`, or a `403` about the token's scope or role (`PACHCA_AUTH_ERROR`, `PACHCA_SCOPE_ERROR`)                               |
| `4`  | Not found (`404`)                                                                                                                                     |

With `-o json` or in a pipe, errors the CLI itself handles go to stderr as one line of JSON with `error`, `code` (HTTP status or `null`), `type`, and, depending on the error, `message`, `request_id`, `hint`, `field` (API field) with `validation_code`, `flag` (CLI flag, for example `--entity-id`), `scope`, `errors`. Each item of `errors` has `message`. An API error item adds `field` when the error names one, the validation code as `code` (a string such as `blank`, unlike the numeric top-level `code`) and sometimes `value`, while an item from the CLI's own check has `flag` instead. Errors from the flag parser itself (an unknown flag, a missing positional argument, a parser-required flag such as `--save` on `files get`, a value of the wrong type) are plain text and exit with `2`, like the JSON validation errors. A few runtime failures, such as an OS key store that cannot be read, are plain text with exit code `1`. So the exit code does not tell text from JSON: read fields from stderr only after `echo "$ERR" | jq -e . >/dev/null 2>&1` succeeds, and otherwise treat it as text.

Types:

- `PACHCA_API_ERROR`: any API answer not covered below, such as a `400` input error, a `403` about access to the object, `404`, `409`, `429`, `5xx`.
- `PACHCA_VALIDATION_ERROR`: a `422` from the API, or the CLI's own check of a flag value (a missing required flag, a value over the length limit or outside the allowed list, invalid JSON in a flag).
- `PACHCA_AUTH_ERROR` (no token, `401`, `403` `role_forbidden`), `PACHCA_SCOPE_ERROR` (missing scope in `scope`), `PACHCA_AUTH_LOGIN_ERROR` (`pachca auth login` failed).
- `PACHCA_DESTRUCTIVE_OP_ERROR`: a delete without `--force` in non-interactive mode.
- `PACHCA_USAGE_ERROR` (wrong flag combination, unknown profile, an `update` command with no fields to change, a file that does not exist, invalid JSON in `--input` or `--data` of `pachca api`, `pachca auth login` without a token in non-interactive mode), `PACHCA_NETWORK_ERROR`, `PACHCA_TIMEOUT_ERROR`, `PACHCA_COMMAND_NOT_FOUND` (with `suggestions`), `PACHCA_NOT_FOUND_ERROR` (unknown endpoint in `pachca api --describe`).

Input errors come back as both `400` and `422`, so branch on `type` together with `code`, and keep `request_id` for support.

```bash
ERR=$(pachca users get 999 -o json 2>&1 >/dev/null)
if echo "$ERR" | jq -e . >/dev/null 2>&1; then
  case "$(echo "$ERR" | jq -r '"\(.type) \(.code)"')" in
    PACHCA_AUTH_ERROR*|PACHCA_SCOPE_ERROR*) echo "check token and scopes" ;;
    PACHCA_VALIDATION_ERROR*|PACHCA_USAGE_ERROR*|"PACHCA_API_ERROR 400") echo "fix the input" ;;
    PACHCA_DESTRUCTIVE_OP_ERROR*) echo "add --force only for a deletion the user asked for" ;;
    *) echo "$ERR" ;;
  esac
else
  echo "$ERR"   # plain text from the flag parser or a runtime failure
fi
```

## Raw requests with `pachca api`

Use typed commands first. `pachca api` is for a method without a convenient wrapper, or for debugging. `pachca api DELETE …` deletes at once: it never asks for confirmation and has no `--force` check, in a terminal or not. Run it only for a deletion the user asked for, never to get around a typed delete that was refused for a missing `--force`, and check it with `--dry-run` first.

- `pachca api GET /messages --query chat_id=123`
- `-F key=value` typed field (numbers and booleans converted, `@file` reads a file); `-f key=value` always a string. Nested keys: `-F 'message[entity_id]=123'` (quote it: zsh treats unquoted brackets as a glob).
- `--data '<json>'` inline body; `--input payload.json` or `--input -` from stdin.
- It prints the raw API response, `data` and `meta` included, so it is the way to read cursors from the CLI.
- Before a raw call, read the endpoint: `pachca api <METHOD> <path> --describe` (also `--spec`, `--docs`); list endpoints with `pachca api ls`.

## Files from the CLI

- `pachca upload <file>` gets the signature, uploads, and returns the `key` for `files[].key` (`-o json | jq -r '.key'`). The key ends in the uploaded file's name, and the `name` you send next to it must keep the same extension, or the send fails with `422` `wrong_params`. `--name <file name>` sets the name the key ends in: from stdin pass it with the extension you need (`cat data.csv | pachca upload - --name data.csv`), otherwise the key ends in `stdin` with no extension and the file can be attached only under a name without one.
- `pachca files get <id> --save <path>` downloads an attachment.
