from .generator import BASE_DIR, PACKAGE_NAME, PROJECT_NAME

__all__ = (
    "BASE_DIR",
    "PACKAGE_NAME",
    "PROJECT_NAME",
)
